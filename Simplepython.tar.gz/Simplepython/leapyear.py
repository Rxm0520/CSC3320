year = int(raw_input("Enter a year: "))
if((year % 100 ==0) and (year % 400 == 0)):
	print("%d is a Leap Year." % year)
elif(year %4 ==0):
	print("%d is a Leap Year." % year)
else:
	print("%d is not the Leap Year." % year)
