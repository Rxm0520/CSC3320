def Palindrome(n): 
  temp = 0;
  for i in range(1, n+1):
    temp = temp * 10;
    temp = temp + 9;
    tempNum = 1 + temp//10;
    maxNum = 0;

  for i in range(temp, tempNum - 1, -1):
    for j in range(i, tempNum - 1, -1):
      num = i * j;
      if (num < maxNum):
        break;
      number = num;
      opposite = 0;

      while (number != 0):
        opposite = opposite * 10 + number % 10;
        number =number // 10;

      if (num == opposite and num > maxNum):
         maxNum = num ;

  return maxNum;

x = 2
y = 3
print("The largest palindrome number for 2 digits number is: ");
print(Palindrome(x));
print("The largest palindrome number for 3 digits number is: ");
print(Palindrome(y));

