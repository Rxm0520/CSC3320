input = raw_input("Enter a Number: ")
print input
print type(input)
num = int(input)
print num
print type(num)
