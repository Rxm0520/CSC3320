input = raw_input("Enter a String: ")
print "You entered: ",input
