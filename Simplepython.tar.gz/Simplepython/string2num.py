ones = ['zero','one','two','three','four','five','six','seven','eight','nine']
overOnes = ['eleven','twelve','thirteen','fourteen','fifteen','sixteen',
'seventeen','eighteen','nineteen']
tens = ['ten','twenty','thirty','forty','fifty','sixty','seventy','eighty',
'ninety','one hundred']

def findNum(str):
 try:
  num = ones.index(str)
 except:
  try:
    num = 11 + overOnes.index(str)
  except:
    num =tens.index(str)+1
    num = num*10
 return num
number = raw_input("Enter a number in word below 100: ")
number = number.split('-');
n = len(number)
if(n==1):
 num = findNum(number[0])
 print num
else:
 ten = findNum(number[0])
 one = findNum(number[1])
 print(ten+one)
