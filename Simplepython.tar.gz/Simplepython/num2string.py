ones = ['zero','one','two','three','four','five','six','seven','eight','nine']
overOnes = ['eleven','twelve','thirteen','fourteen','fifteen','sixteen',
'seventeen','eighteen','nineteen']
tens = ['ten','twenty','thirty','forty','fifty','sixty','seventy','eighty',
'ninety','one hundred']


number=int(raw_input("Enter number: "))

if number < 10:
  print(ones[number])
elif number % 10 == 0:
  print(tens[int(number/10)-1])
elif number < 20 and number > 10:
  print(overOnes[number%10-1])
else:
 ten = tens[int(number / 10) - 1]
 one = ones[number % 10]
 print ten,"-",one
