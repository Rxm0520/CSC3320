ones = ['zero','one','two','three','four','five','six','seven','eight','nine']
overOnes = ['eleven','twelve','thirteen','fourteen','fifteen','sixteen',
'seventeen','eighteen','nineteen']
tens = ['ten','twenty','thirty','forty','fifty','sixty','seventy','eighty',
'ninety','one hundred']

def findNum(str):
 try:
  num = ones.index(str)
 except:
  try:
    num = 11 + overOnes.index(str)
  except:
    num =tens.index(str)+1
    num = num*10
 return num
firstNum = raw_input("Enter a number in word below 100: ")
secNum = raw_input("Enter a another in word below 100: ")

firstNum = firstNum.split('-');
n = len(firstNum)
if(n==1):
 frist = findNum(firstNum[0])
 fn = frist
else:
 firstTen = findNum(firstNum[0])
 firstOne = findNum(firstNum[1])
 fn = firstTen +firstOne

secNum = secNum.split('-');
n = len(secNum)
if(n==1):
 sec = findNum(secNum[0])
 se = sec
else:
 secTen = findNum(secNum[0])
 secOne = findNum(secNum[1])
 se = secTen + secOne

product = fn * se
print fn,"*",se,"=",product


