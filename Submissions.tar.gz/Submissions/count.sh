echo "number of" "$1"" ""$2"
grep  "$1" 2.asr | grep -c "$2"

