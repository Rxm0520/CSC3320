For this assignment I created a Submissions folder, then I went to change the permission of the folder, by using chmod. Then I went to the directory of /home/cumoja1/3320 by using cd. I went in and copied the txt file of The hunger games to my submissions directory,buy using cp. I went back to my submissions and opened up The hunger games file, I choose the charater Glimmer,and I replace all occurence of her name with my name Shuang by using :%s. Then I saved the file using :wq in command mode. I renamed The hunger games file by using mv.

Using the command chown I can change the user owner and the group owner of the file. 
To change the user owner:	chown cumoja1: Submissions
To change the group owner:	chown :cumoja1 Submissions
To change both :	chown cumoja1:cumoja1 Submissions

using chgrp can only change the group owner of the file.
chgrp cumoja1 Submissions

These will still allow the orginal owner "me" to read the file.
