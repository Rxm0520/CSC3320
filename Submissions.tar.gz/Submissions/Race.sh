#!/bin/bash/
grep  "$1" 2.asr |grep "$2" 
