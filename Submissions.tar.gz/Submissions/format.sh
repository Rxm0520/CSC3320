#!bin/bash/
tr '\n' ' ' < "$*" | sed 's/)" /)"\n \n/g' | sed 's/, /./g' |sed 's/)".1/)".\n1/g' | sed 's/InjuryCityGeo/InjuryCityGeo\n/g' | sed 's/.13-0052/\n13-0052/g' |  column -s, -t|less -S
