
import binascii

text = raw_input("Enter a string\n")
data = binascii.b2a_base64(text)
print("String to binary\n")
print(data)
dataB = binascii.a2b_base64(data)
print("Binary back to string\n")
print(dataB)
