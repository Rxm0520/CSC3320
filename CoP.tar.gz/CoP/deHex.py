import binascii
def dehexify(hex):
	data = open(hex,"r").read()
	unhex = binascii.unhexlify(data)
	print(unhex)
dehexify("hexaDump")
