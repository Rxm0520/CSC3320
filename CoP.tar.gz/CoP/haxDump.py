import binascii
import sys

def fileToHexDump(read,write):
	hexaStr = ""
	byte = ""
	with open(read,"rb") as f:
		byte = f.read(1)
		while byte !="":
			hexaStr +=binascii.hexlify(byte)
			byte = f.read(1)
	print("Write hexa array")
	print(hexaStr)
	f = open(write,"w")
	f.write(hexaStr)
	f.close()

fileToHexDump(sys.argv[1],"hexaDump")
