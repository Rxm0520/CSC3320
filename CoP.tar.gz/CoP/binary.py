from os import system
binaryData = open("/home/sli34/CoP/data","rb").read()
f = open("./copiedData","wb")
f.write(binaryData)
f.close()
print("print out the binary file")
