#!/bin/bash/

grep -v 'ATOM\|CONECT\|HETATM\|TER\|END' "$*" | grep -Eo '^.[^ ]+' | sort -u


