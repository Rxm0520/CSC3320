!#/bin/bash/
sed 's/HETATM/ATOM  /g' "$*" | sed 's/MSE/MET/g'
