For this part I figure out for 1 we  need to take out the headers that are proivded. So I used grep -v, Then I use grep -Eo '^.[^ ] to print out the first column, and then I use sort -u to make every header to only print once.
For 2 I wanted to change HETATM and MSE to ATOM and MET , so I use sed 's/HETATM/ATOM  /g and sed 's/MSE/MET/g'.

For 3, I wrote a awk, to to find the max and min of x,y,z for ATOM buy seting $1== ATOM. I intial max to 0 and for every time  the number of x,y,z is greater than max, max is being replace. 
For min, I intial it to 1000, a large number and when x,y,z is lower than min ,min is replaced.

For 4, I added the each column to get a total, and for every time I add, I kept count, and at last the total is divide by the time I added.

For 5 I used sed 's to change HOH to WAT same as number 2.

6 I sort coulmn number 11 and then only grep the lines with ATOM in it. Then it is printed.

