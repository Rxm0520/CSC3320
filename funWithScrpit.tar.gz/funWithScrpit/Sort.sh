#!bin/bash/
sort -k11 4HKD.pdb | grep "ATOM" "$*"	

