import sys


original = open(sys.argv[1]).read()
coded = open(sys.argv[2], "w")
key = int(sys.argv[3])
original = original.lower()
letter = ""

for orLetter in original:
 if(ord(orLetter) >= ord('a') and ord(orLetter) <= ord('z')):
  letter = chr(97 + (ord(orLetter) + key - 97) % 26)
  coded.write(letter)
 else:
  coded.write(orLetter)


coded.close() 
