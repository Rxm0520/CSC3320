import sys

coded = open(sys.argv[1]).read()
decoded = open(sys.argv[2],"w")

coded = coded.lower()

numOfLetter = [0] *26

for letter in coded:
 if(letter.isalpha() != False):
  numOfLetter[ord(letter) - ord('a')] +=1
char = ord('a')
templetter = char
tempmax = 0
for i in range(0, 26):
 print "Letter ",chr(char)," occured ",numOfLetter[i],"times"
 if(tempmax < numOfLetter[i]):
  tempmax = numOfLetter[i] 
  templetter = char
 char +=1

key = abs(templetter - ord('e'))

print "The possbile key is: ",key

for orLetter in coded:
 if(ord(orLetter) >= ord('a') and ord(orLetter) <= ord('z')):
  letter = ord(orLetter)-key
  if(letter < 97):
   letter = letter + 26
  decoded.write(chr(letter))
 else:
  decoded.write(orLetter)

