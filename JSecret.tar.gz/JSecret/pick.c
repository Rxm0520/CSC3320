#include<stdio.h>
#include<stdlib.h>

int main(int pnum, char *param[])
{	
	if(pnum == 3){

        FILE *original;
        FILE *decodedfile;
       decodedfile = fopen (param[2],"w");
        int emax = 0;
        int tmax = 0;
        int temp;
        int i;
        for(i = 1 ; i < 26 ; i++){
                int e = 0;
                int t = 0;
                int letter;
                 original = fopen (param[1],"r");
                 while ((letter = fgetc(original)) != EOF) {
                        int asc = letter;
                        if( asc >= 'A' && asc<='Z'){
                        asc += 32;
                           }

                         if(asc >= 'a' && asc <= 'z'){
                                  asc = asc-i;
                                if(asc < 97){
                                 asc = asc + 26;
                                        }
                        if("%c",asc == 'e'){
                                e++;
                                }
                        if("%c",asc == 't'){
                                t++;
                                }

                        }
                 }
        if(e > emax){
                emax = e;
                if(t > tmax){
                tmax = t;
                temp = i;
                        }
                }
              }

                int key = temp;
                int letter;
                 original = fopen (param[1],"r");
                 while ((letter = fgetc(original)) != EOF) {
                        int asc = letter;
                        if( asc >= 'A' && asc<='Z'){
                        asc += 32;
                           }

                         if(asc >= 'a' && asc <= 'z'){
                                  asc = asc-key;
                                if(asc < 97){
                                 asc = asc + 26;
                                        }
                 fprintf(decodedfile, "%c",asc);
                 }else{
                 fprintf(decodedfile, "%c",letter);
                                        }
                                 }

		printf("num of e: %d\n",emax);
		printf("num of t: %d\n",tmax);
		printf("key : %d\n",key);

	}
	if(pnum ==4){
        FILE *original;
        FILE *codedfile;

        original = fopen (param[1],"r");
        codedfile = fopen (param[2],"w");
        int key = atoi(param[3]);
        int letter;

        while ((letter = fgetc(original)) != EOF) {
                int asc = letter;

        if( asc >= 'A' && asc<='Z'){
                asc += 32;
        }

        if(asc >= 'a' && asc <= 'z'){
                asc = 97 + (asc + key - 97) % 26;
                fprintf(codedfile, "%c",asc);
        }else{
                fprintf(codedfile, "%c",letter);
                }
        }

        fclose(original);
        fclose(codedfile);

	}		

return 0;
}
