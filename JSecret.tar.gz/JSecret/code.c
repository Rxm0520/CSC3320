#include<stdio.h>
#include<stdlib.h>


int main(int pnum, char *param[])
{
        FILE *original;
        FILE *codedfile;

        original = fopen (param[1],"r");
        codedfile = fopen (param[2],"w");
        int key = atoi(param[3]);
        int letter;

        while ((letter = fgetc(original)) != EOF) {
                int asc = letter;

        if( asc >= 'A' && asc<='Z'){
                asc += 32;
        }

        if(asc >= 'a' && asc <= 'z'){
                asc = 97 + (asc + key - 97) % 26;
                fprintf(codedfile, "%c",asc);
        }else{
                fprintf(codedfile, "%c",letter);
                }
        }

        fclose(original);
        fclose(codedfile);

        return 0;
}
