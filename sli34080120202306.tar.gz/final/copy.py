from os import system

system("awk '{if($1 != \"total\" ){print $2}}' FINALinstruction > Files") 
system("xargs -a Files cp -t ~/final/FINALc/copies")
system("xargs -a Files cp -t ~/final/FINALpython/copies")

