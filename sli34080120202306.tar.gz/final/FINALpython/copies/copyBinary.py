import os

def encrypt(File):
	result = ""
	key = 150
	for i in range(len(File)):
		char = File[i]
		result += chr((ord(char) + key)%256)
		if key - 1 > 0:
			key = (key -1) % 256
		else:
			key =255
	return result


for filename in os.listdir(os.getcwd()):
	with open(os.path.join(os.getcwd(),filename),"rb")as f:
		File = f.read()
		Binary = encrypt(File)
		FileBinary = open("/home/sli34/final/FINALpython/encrypted/"+filename,"wb")
		FileBinary.write(Binary)
		FileBinary.close()	
