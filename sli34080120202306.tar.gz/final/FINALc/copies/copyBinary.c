#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char **argv){
    int BUFFER_SIZE = 1024;
    DIR* File;
    struct dirent* in_file;
    FILE    *destFile;
    FILE    *startFile;
    char    buffer[BUFFER_SIZE];
    int c,i;
    int key = 150;
    File = opendir("/home/sli34/final/FINALc/copies"); 
    while ((in_file = readdir(File))) 
    {
        if (!strcmp (in_file->d_name, "."))
            continue;
        if (!strcmp (in_file->d_name, ".."))    
            continue;
        startFile = fopen(in_file->d_name, "rb");
        char path[100] = "/home/sli34/final/FINALc/encrypted/";
        char fileName[40];
        strcpy(fileName,in_file->d_name);
        strcat(path,fileName);
        destFile = fopen(path, "wb");
        while((c = fgetc(startFile))!=EOF) {
            c += key;
            key = (key - 1) > 0 ? (key - 1) % 256 : 255;
           fputc(c,destFile);
	}
        fclose(startFile);
        fclose(destFile);
    }
    closedir(File);
    return 0;
}

