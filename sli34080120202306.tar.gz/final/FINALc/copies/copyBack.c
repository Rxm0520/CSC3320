#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>



int main(int argc, char **argv)
{
    int BUFFER_SIZE = 1024;
    DIR *FD;
    struct dirent *in_file;
    FILE *common_file;
    FILE *entry_file;
    FILE *temp_file;
    char buffer[BUFFER_SIZE];
    int c;
    int key = 150;
   FD = opendir("/home/sli34/final/FINALc/encrypted/");
    while ((in_file = readdir(FD)))
    {
        if (!strcmp(in_file->d_name, "."))
            continue;
        if (!strcmp(in_file->d_name, ".."))
            continue;
        entry_file = fopen(in_file->d_name, "rb");

        char s1[80] = "/home/sli34/final/FINALc/decrypted/";
        char s2[20];
        strcpy(s2, in_file->d_name);
        strcat(s1, s2);
        common_file = fopen(s1, "wb");
        while((c = fgetc(entry_file))!=EOF) {
            c = c - key;
            key = (key - 1) > 0 ? (key - 1) % 256 : 255;
            fputc(c,common_file);
        }
        
        fclose(entry_file);
        fclose(common_file);
    }
    closedir(FD);
    return 0;
}
