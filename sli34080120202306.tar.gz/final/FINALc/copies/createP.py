from os import system
system("mkdir FINALpython")
system("mkdir -p FINALpython/copies")
system("mkdir -p FINALpython/encrypted")
system("mkdir -p FINALpython/decrypted")
system("cp createP.py FINALpython")

