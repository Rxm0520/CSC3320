#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char *argv[]) {
	char createA[100];
	char createB[100];
	char createC[100];
        char createD[100];
        char createE[100];

	strcpy(createA,"mkdir FINALc");
	system(createA);
	
	strcpy(createB,"mkdir FINALc/copies");
	system(createB);

	strcpy(createC,"mkdir FINALc/encrypted");
	system(createC);
	
	strcpy(createD,"mkdir FINALc/decrypted");
	system(createD);

	strcpy(createE,"cp createC.c FINALc");
        system(createE);

	if(argc == 2){
		strcpy(createE,"gcc createC.c -o ");		
		strcat(createE,argv[1]);
		system(createE);
		strcpy(createE,"mv ");
		strcat(createE,argv[1]);
		strcat(createE," FINALc");
		system(createE);

	}	
	       
	
	
return 0;
}
