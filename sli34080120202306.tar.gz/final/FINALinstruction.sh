#!/bin/bash/
ls -la | egrep -v  ^d|awk '{if($1 != "total"){print $1, $9}else{print $0}}' > FINALinstruction

