For this part of the lab, I use mostly awk files.
First I wanted to change the number into all postive and then keeping the minus sign temporarily.
I change the sign by using gsub("-","", $0);
Then I learn that using split($0,name,"/"); can divide each part into arrays,but I did not use it beacuase I divide using substring holding different part of it, and  getting each part.
Then I found each number and multiply galleon by 23*17 and suckles by 17,and then adding them all to knuts 
which gives a sum of total knuts, then by putting the sign back into place where it has minus sign, then printing out the final answer.

For the part putting the knut into its orignal form,I took out the minus sign,and  divided total knuts by 17 and get the remainder,to be the left knuts, then the then the number I get I divide by 23 to get the galleon and the remainder is the sickles we have. Then I print it in orginal form, by putting the minus back where it suppse to be.

For the last part I ceate a sum awk,to add all the sum of knuts into total, then I turn it back to the galleon sickels form.
